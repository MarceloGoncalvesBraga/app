
from flask import Flask,render_template
from application.controller import home_controller
from application.controller import produto_controller
import os

main = Flask(__name__,
static_folder=os.path.abspath("application/view/static"),
template_folder=os.path.abspath("application/view/templates")
)
