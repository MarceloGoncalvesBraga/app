
from application import main

''' if __name__ == '__main__':
    main.run(debug(True)) 
 '''

#flask_debug=1
#flask_developer